/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package database;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingWorker;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.UIManager;

/**
 * Student search window (dbsample.tbl_students).
 *
 * Layout and component properties live in FrmTableSampleAmora.form (edit them
 * in NetBeans Design view). Everything below the generated-code region is
 * hand-written: table styling, database loading and the shared search method.
 *
 * @author zeal
 */
public class FrmTableSampleDelatorre extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmTableSampleDelatorre.class.getName());

    // Palette used by tabledesign() and the status label.
    private static final Color HEADER_BG = new Color(67, 56, 202);
    private static final Color ROW_ALT = new Color(255, 0, 255);
    private static final Color ROW_SELECTED = new Color(99, 102, 241);
    private static final Color GRID = new Color(226, 232, 240);
    private static final Color STATUS_OK = new Color(71, 85, 105);
    private static final Color STATUS_ERROR = new Color(185, 28, 28);

    /** Only the newest query may update the table (older, slower ones are ignored). */
    private int latestRequest = 0;

    /** Waits briefly after the last keystroke so typing "Freddy" runs one query, not six. */
    private final javax.swing.Timer searchDelay = new javax.swing.Timer(300, e -> runSearch());

    /**
     * Creates new form FrmTableSampleAmora
     */
    public FrmTableSampleDelatorre() {
        initComponents();
      
        tabledesign(tblStudents);

        // Search as you type (registered here, not in the form, so the .form stays untouched).
        searchDelay.setRepeats(false);
        txtSearch.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                searchDelay.restart();
            }

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                searchDelay.restart();
            }

            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                searchDelay.restart();
            }
        });

        this.setLocationRelativeTo(null);
        runSearch(); // empty search box -> loads every record
    }

    // ------------------------------------------------------------------
    // Table styling (kept out of initComponents so the form stays editable)
    // ------------------------------------------------------------------
  
private void tabledesign(JTable table) {
    // Table styling through UIManager
    UIManager.put("Table.font", new Font("Segoe UI", Font.PLAIN, 15));
    UIManager.put("Table.foreground", new Color(15, 23, 42));
    UIManager.put("Table.background", Color.WHITE);
    UIManager.put("Table.selectionBackground", new Color(99, 102, 241));
    UIManager.put("Table.selectionForeground", Color.WHITE);
    UIManager.put("Table.gridColor", new Color(226, 232, 240));
    UIManager.put("Table.rowHeight", 34);

    // Custom alternating row color
    UIManager.put("Table.alternateRowColor", new Color(161, 201, 188));

    // Table header styling
    UIManager.put("TableHeader.background", new Color(218, 41, 28));
    UIManager.put("TableHeader.foreground", Color.WHITE);
    UIManager.put("TableHeader.font", new Font("Segoe UI", Font.BOLD, 15));

    // Apply UIManager defaults to the table
    table.setFont(UIManager.getFont("Table.font"));
    table.setForeground(UIManager.getColor("Table.foreground"));
    table.setBackground(UIManager.getColor("Table.background"));
    table.setRowHeight((Integer) UIManager.get("Table.rowHeight"));
    table.setShowVerticalLines(false);
    table.setGridColor(UIManager.getColor("Table.gridColor"));
    table.setIntercellSpacing(new java.awt.Dimension(0, 1));
    table.setSelectionBackground(UIManager.getColor("Table.selectionBackground"));
    table.setSelectionForeground(UIManager.getColor("Table.selectionForeground"));
    table.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
    table.setAutoCreateRowSorter(true);
    table.getTableHeader().setReorderingAllowed(false);
    table.getTableHeader().setPreferredSize(new java.awt.Dimension(100, 40));

    // Header renderer
    table.getTableHeader().setDefaultRenderer(new DefaultTableCellRenderer() {
        @Override
        public Component getTableCellRendererComponent(
                JTable t, Object value, boolean isSelected,
                boolean hasFocus, int row, int column) {

            JLabel header = (JLabel) super.getTableCellRendererComponent(
                    t, value, false, false, row, column);

            header.setOpaque(true);
            header.setBackground(UIManager.getColor("TableHeader.background"));
            header.setForeground(UIManager.getColor("TableHeader.foreground"));
            header.setFont(UIManager.getFont("TableHeader.font"));
            header.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 14, 0, 14));
            header.setHorizontalAlignment(column == 0 ? JLabel.CENTER : JLabel.LEFT);

            return header;
        }
    });

    // Table body renderer
    DefaultTableCellRenderer body = new DefaultTableCellRenderer() {
        @Override
        public Component getTableCellRendererComponent(
                JTable t, Object value, boolean isSelected,
                boolean hasFocus, int row, int column) {

            JLabel cell = (JLabel) super.getTableCellRendererComponent(
                    t, value, isSelected, false, row, column);

            cell.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 14, 0, 14));
            cell.setHorizontalAlignment(column == 0 ? JLabel.CENTER : JLabel.LEFT);

            if (isSelected) {
                cell.setBackground(UIManager.getColor("Table.selectionBackground"));
                cell.setForeground(UIManager.getColor("Table.selectionForeground"));
            } else {
                cell.setBackground(row % 2 == 0
                        ? UIManager.getColor("Table.background")
                        : UIManager.getColor("Table.alternateRowColor"));
                cell.setForeground(UIManager.getColor("Table.foreground"));
            }

            return cell;
        }
    };

    table.setDefaultRenderer(Object.class, body);
    table.setDefaultRenderer(Integer.class, body);
    table.setDefaultRenderer(String.class, body);

    table.getColumnModel().getColumn(0).setPreferredWidth(160);
    table.getColumnModel().getColumn(1).setPreferredWidth(560);
}

    // ------------------------------------------------------------------
    // Database loading
    // ------------------------------------------------------------------

    /** The single search entry point: typing (after a short pause), the Enter key and the start-up load all use it. */
    private void runSearch() {
        searchDelay.stop(); // Enter runs the search immediately, no need to wait for the typing timer
        loadTable(txtSearch.getText().trim());
    }

    /**
     * Loads the table from dbsample.tbl_students on a background thread so the
     * window never freezes. A blank term loads every record; otherwise a
     * PreparedStatement search by ID or name is used (see Procedure).
     */
private void loadTable(String term) {
        final int request = ++latestRequest;
        setStatus("Loading...", false);

        // Update the generic type of SwingWorker from List<Procedure.Student> to Procedure.DynamicResult
        new SwingWorker<Procedure.DynamicResult, Void>() {
            @Override
            protected Procedure.DynamicResult doInBackground() throws SQLException {
                // Now returns the dynamic columns and rows
                return Procedure.searchStudents(term);
            }

            @Override
            protected void done() {
                if (request != latestRequest) {
                    return; // a newer search is already running
                }
                try {
                    // get() now returns a Procedure.DynamicResult
                    showStudents(get(), term);
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                } catch (java.util.concurrent.ExecutionException ex) {
                    showFailure(ex.getCause());
                }
            }
        }.execute();
    }

   private void showStudents(Procedure.DynamicResult result, String term) {
        DefaultTableModel model = (DefaultTableModel) tblStudents.getModel();

        // 1. Dynamically apply the column names pulled from the database
        model.setColumnIdentifiers(result.columns());

        // 2. Clear out any old data
        model.setRowCount(0);

        // 3. Loop through the rows and add them to the table
        for (Object[] rowData : result.rows()) {
            model.addRow(rowData);
        }

        // 4. Update the status label
        int rowCount = result.rows().size();
        if (rowCount == 0) {
            setStatus(term.isEmpty() ? "The student table is empty."
                    : "No students match \"" + term + "\".", false);
        } else {
            String countText = rowCount + (rowCount == 1 ? " student" : " students");
            setStatus(term.isEmpty() ? "Showing all " + countText + "."
                    : "Found " + countText + " matching \"" + term + "\".", false);
        }
    }

    private void showFailure(Throwable cause) {
        logger.log(java.util.logging.Level.WARNING, "Database operation failed", cause);
        ((DefaultTableModel) tblStudents.getModel()).setRowCount(0); // never show stale or invented rows
        setStatus("Database error - see message.", true);
        JOptionPane.showMessageDialog(this, Procedure.explain(cause),
                "Database error", JOptionPane.ERROR_MESSAGE);
    }

    private void setStatus(String text, boolean error) {
        lblStatus.setText(text);
        lblStatus.setForeground(error ? STATUS_ERROR : STATUS_OK);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlRoot = new javax.swing.JPanel();
        pnlHeader = new javax.swing.JPanel();
        lblTitle = new javax.swing.JLabel();
        lblSubtitle = new javax.swing.JLabel();
        pnlSearch = new javax.swing.JPanel();
        lblSearch = new javax.swing.JLabel();
        txtSearch = new javax.swing.JTextField();
        scrTable = new javax.swing.JScrollPane();
        tblStudents = new javax.swing.JTable();
        lblStatus = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Data Integration - Table - Amora");

        pnlRoot.setBackground(new java.awt.Color(248, 250, 252));

        pnlHeader.setBackground(new java.awt.Color(255, 153, 153));

        lblTitle.setFont(new java.awt.Font("Segoe UI", 1, 30)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setText("Data Integration - Table - Delatorre");

        lblSubtitle.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblSubtitle.setForeground(new java.awt.Color(199, 210, 254));
        lblSubtitle.setText("Search student records by student ID or name");

        javax.swing.GroupLayout pnlHeaderLayout = new javax.swing.GroupLayout(pnlHeader);
        pnlHeader.setLayout(pnlHeaderLayout);
        pnlHeaderLayout.setHorizontalGroup(
            pnlHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHeaderLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(pnlHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblSubtitle)
                    .addComponent(lblTitle))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlHeaderLayout.setVerticalGroup(
            pnlHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHeaderLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblTitle)
                .addGap(4, 4, 4)
                .addComponent(lblSubtitle)
                .addGap(22, 22, 22))
        );

        pnlSearch.setBackground(new java.awt.Color(238, 242, 255));

        lblSearch.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblSearch.setForeground(new java.awt.Color(30, 41, 59));
        lblSearch.setText("Search:");

        txtSearch.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtSearch.setToolTipText("Type a student ID or part of a name, then press Enter");
        txtSearch.addActionListener(this::txtSearchActionPerformed);

        javax.swing.GroupLayout pnlSearchLayout = new javax.swing.GroupLayout(pnlSearch);
        pnlSearch.setLayout(pnlSearchLayout);
        pnlSearchLayout.setHorizontalGroup(
            pnlSearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlSearchLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(lblSearch)
                .addGap(10, 10, 10)
                .addComponent(txtSearch, javax.swing.GroupLayout.DEFAULT_SIZE, 320, Short.MAX_VALUE)
                .addGap(28, 28, 28))
        );
        pnlSearchLayout.setVerticalGroup(
            pnlSearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlSearchLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(pnlSearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSearch)
                    .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16))
        );

        tblStudents.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "student_id", "name", "Title 3", "Title 4"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblStudents.setFillsViewportHeight(true);
        scrTable.setViewportView(tblStudents);

        lblStatus.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblStatus.setForeground(new java.awt.Color(71, 85, 105));
        lblStatus.setText("Connecting to dbsample...");

        javax.swing.GroupLayout pnlRootLayout = new javax.swing.GroupLayout(pnlRoot);
        pnlRoot.setLayout(pnlRootLayout);
        pnlRootLayout.setHorizontalGroup(
            pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlHeader, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(pnlSearch, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(scrTable, javax.swing.GroupLayout.DEFAULT_SIZE, 720, Short.MAX_VALUE)
                    .addComponent(lblStatus, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(24, 24, 24))
        );
        pnlRootLayout.setVerticalGroup(
            pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addComponent(pnlHeader, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(pnlSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addComponent(scrTable, javax.swing.GroupLayout.DEFAULT_SIZE, 340, Short.MAX_VALUE)
                .addGap(8, 8, 8)
                .addComponent(lblStatus)
                .addGap(12, 12, 12))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlRoot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlRoot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchActionPerformed
        // Enter pressed in the search box
        runSearch();
    }//GEN-LAST:event_txtSearchActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new FrmTableSampleDelatorre().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel lblSearch;
    private javax.swing.JLabel lblStatus;
    private javax.swing.JLabel lblSubtitle;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JPanel pnlHeader;
    private javax.swing.JPanel pnlRoot;
    private javax.swing.JPanel pnlSearch;
    private javax.swing.JScrollPane scrTable;
    private javax.swing.JTable tblStudents;
    private javax.swing.JTextField txtSearch;
    // End of variables declaration//GEN-END:variables
}
