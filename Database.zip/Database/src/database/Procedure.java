/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * JDBC helper for the dbsample.tbl_students table (XAMPP MySQL/MariaDB).
 *
 * Every query opens its own connection and closes it with try-with-resources,
 * so there is no shared static Connection/Statement/ResultSet to leak or to
 * hit a NullPointerException after a failed connection.
 *
 * All connection settings live in the constants below. They can be overridden
 * without editing code by adding VM options in NetBeans
 * (Project Properties > Run > VM Options), for example:
 *     -Ddb.password=mySecret
 *     -Ddb.url=jdbc:mysql://localhost:3307/dbsample
 *
 * @author zeal
 */
public class Procedure {

    // ---- Centralized connection settings (XAMPP defaults) ----
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String DEFAULT_URL = "jdbc:mysql://localhost:3306/dbsample";
    private static final String DEFAULT_USER = "root";
    private static final String DEFAULT_PASSWORD = ""; // XAMPP default is empty; set your real one via -Ddb.password
    private static final int CONNECT_TIMEOUT_MS = 5000;

    private static final String SQL_ALL
            = "SELECT * FROM tbl_students";

    /** Holds dynamic column headers and the corresponding rows of data. */
    public record DynamicResult(String[] columns, List<Object[]> rows) {
    }

    private Procedure() {
    }

    /** Opens a new connection. The caller must close it (use try-with-resources). */
    public static Connection getConnection() throws SQLException {
        try {
            Class.forName(DRIVER);
        } catch (ClassNotFoundException ex) {
            throw new SQLException("MySQL JDBC driver not found (" + DRIVER + "). "
                    + "Add mysql-connector-j to the project's Libraries (see lib/README.txt).", "DRIVER", ex);
        }
        Properties props = new Properties();
        props.setProperty("user", System.getProperty("db.user", DEFAULT_USER));
        props.setProperty("password", System.getProperty("db.password", DEFAULT_PASSWORD));
        props.setProperty("connectTimeout", String.valueOf(CONNECT_TIMEOUT_MS));
        return DriverManager.getConnection(System.getProperty("db.url", DEFAULT_URL), props);
    }

    /** All students, dynamically fetching every column. */
    public static DynamicResult getAllStudents() throws SQLException {
        try (Connection conn = getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_ALL);
                ResultSet rs = ps.executeQuery()) {
            return readDynamic(rs);
        }
    }

    /**
     * Dynamically detects all columns and searches for the term in every single one.
     */
    public static DynamicResult searchStudents(String term) throws SQLException {
        String trimmed = term == null ? "" : term.trim();
        if (trimmed.isEmpty()) {
            return getAllStudents();
        }
        String pattern = "%" + escapeLike(trimmed) + "%";

        try (Connection conn = getConnection()) {
            // 1. Quickly grab the column names without fetching any data
            List<String> columnNames = new ArrayList<>();
            try (PreparedStatement metaPs = conn.prepareStatement("SELECT * FROM tbl_students WHERE 1=0");
                 ResultSet metaRs = metaPs.executeQuery()) {
                
                java.sql.ResultSetMetaData meta = metaRs.getMetaData();
                for (int i = 1; i <= meta.getColumnCount(); i++) {
                    columnNames.add(meta.getColumnName(i));
                }
            }

            // If the table has no columns somehow, return empty results
            if (columnNames.isEmpty()) {
                return new DynamicResult(new String[0], new ArrayList<>());
            }

            // 2. Build the dynamic SQL query string
            StringBuilder sql = new StringBuilder("SELECT * FROM tbl_students WHERE ");
            for (int i = 0; i < columnNames.size(); i++) {
                if (i > 0) {
                    sql.append(" OR ");
                }
                // Backticks protect against column names that are reserved SQL words
                // CAST ensures we can safely do a LIKE search on numbers and dates
                sql.append("CAST(`").append(columnNames.get(i)).append("` AS CHAR) LIKE ? ESCAPE '!'");
            }

            // 3. Prepare the dynamic SQL and bind the search term to EVERY column
            try (PreparedStatement searchPs = conn.prepareStatement(sql.toString())) {
                for (int i = 1; i <= columnNames.size(); i++) {
                    searchPs.setString(i, pattern); // Bind the exact same pattern to each '?'
                }
                
                try (ResultSet rs = searchPs.executeQuery()) {
                    return readDynamic(rs);
                }
            }
        }
    }

    /** Dynamically extracts column names and row data from ANY ResultSet */
    private static DynamicResult readDynamic(ResultSet rs) throws SQLException {
        java.sql.ResultSetMetaData meta = rs.getMetaData();
        int colCount = meta.getColumnCount();
        
        // 1. Get column names
        String[] columns = new String[colCount];
        for (int i = 1; i <= colCount; i++) {
            // getColumnLabel handles SQL aliases better than getColumnName
            columns[i - 1] = meta.getColumnLabel(i); 
        }

        // 2. Get row data
        List<Object[]> rows = new ArrayList<>();
        while (rs.next()) {
            Object[] row = new Object[colCount];
            for (int i = 1; i <= colCount; i++) {
                row[i - 1] = rs.getObject(i); // Fetch whatever data type it is
            }
            rows.add(row);
        }
        
        return new DynamicResult(columns, rows);
    }

    private static String escapeLike(String s) {
        return s.replace("!", "!!").replace("%", "!%").replace("_", "!_");
    }

    /** Turns a database failure into a message a person can act on. */
    public static String explain(Throwable ex) {
        // Some drivers wrap the real cause (e.g. "access denied") inside a generic
        // connection error, so inspect the whole cause chain, most specific first.
        List<SQLException> chain = new ArrayList<>();
        for (Throwable t = ex; t != null; t = t.getCause()) {
            if (t instanceof SQLException se) {
                chain.add(se);
            }
        }
        if (chain.isEmpty()) {
            return String.valueOf(ex.getMessage());
        }
        String url = System.getProperty("db.url", DEFAULT_URL);

        for (SQLException se : chain) {
            String state = se.getSQLState() == null ? "" : se.getSQLState();
            String msg = se.getMessage() == null ? "" : se.getMessage().toLowerCase();
            int code = se.getErrorCode();

            if ("DRIVER".equals(state)) {
                return se.getMessage();
            }
            if (code == 1045 || "28000".equals(state) || msg.contains("access denied")) {
                return "MySQL rejected the username/password.\n"
                        + "Set the real password with the VM option -Ddb.password=... "
                        + "(or edit DEFAULT_PASSWORD in Procedure.java).";
            }
            if (code == 1049 || msg.contains("unknown database")) {
                return "Database 'dbsample' does not exist.\nRun database_setup.sql in phpMyAdmin first.";
            }
            if (code == 1146 || "42S02".equals(state)) {
                return "Table 'tbl_students' does not exist in dbsample.\nRun database_setup.sql in phpMyAdmin first.";
            }
        }
        for (SQLException se : chain) {
            String state = se.getSQLState() == null ? "" : se.getSQLState();
            String msg = se.getMessage() == null ? "" : se.getMessage().toLowerCase();
            if (state.startsWith("08") || msg.contains("link failure") || msg.contains("could not connect")) {
                return "Cannot reach the database at " + url + ".\n"
                        + "Open the XAMPP Control Panel and Start the MySQL module, then try again.";
            }
        }
        return chain.get(0).getMessage();
    }
}