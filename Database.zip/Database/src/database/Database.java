/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package database;

/**
 *
 * @author zeal
 */
public class Database {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Standard Swing startup (look and feel + invokeLater + setVisible)
        // lives in the form's main(), so there is only one place to change it.
        FrmTableSampleDelatorre.main(args);
    }
    
}
