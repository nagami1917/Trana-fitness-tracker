MySQL JDBC driver (required at runtime)
=======================================
Put mysql-connector-j-8.0.33.jar in this folder (lib/). The project's classpath
already points to lib/mysql-connector-j-8.0.33.jar, so it works on any computer
that has the jar in this folder - no C:\Users\... paths.

Download: https://dev.mysql.com/downloads/connector/j/  (Platform Independent -> ZIP,
then copy mysql-connector-j-8.0.33.jar out of it).

If you use a different version, either rename the file to the name above, or in
NetBeans: Libraries > Add JAR/Folder, pick the jar, and tick "Relative Path".
