-- ============================================================
-- database_setup.sql  -  Data Integration - Table - Amora
-- Run in phpMyAdmin (SQL tab) or the XAMPP MySQL shell:
--     mysql -u root -p < database_setup.sql
-- Safe to re-run: nothing is dropped or overwritten.
-- ============================================================

CREATE DATABASE IF NOT EXISTS dbsample;

USE dbsample;

CREATE TABLE IF NOT EXISTS tbl_students (
    student_id INT NOT NULL PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);

-- INSERT IGNORE skips the row if student_id 105 already exists.
INSERT IGNORE INTO tbl_students (student_id, name)
VALUES (105, 'Freddy Krueger');

-- Optional check: if 105 holds a different name, this shows the conflict
-- (the script itself never overwrites existing data).
SELECT student_id, name FROM tbl_students WHERE student_id = 105;
